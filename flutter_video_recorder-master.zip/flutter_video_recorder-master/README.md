# Flutter Video Recorder Demo

A Flutter app to showcase Video Recorder demo.

# Demo
<img height="480px" src="https://github.com/flutter-devs/flutter_video_recorder/blob/master/screens/demo.gif">



# Android Screen
<img height="480px" src="https://github.com/flutter-devs/flutter_video_recorder/blob/master/screens/android1.jpg"> <img height="480px" src="https://github.com/flutter-devs/flutter_video_recorder/blob/master/screens/android2.jpg">  <img height="480px" src="https://github.com/flutter-devs/flutter_video_recorder/blob/master/screens/android3.jpg"> 


# iOS Screen
<img height="480px" src="https://github.com/flutter-devs/flutter_video_recorder/blob/master/screens/iphone1.jpg"> <img height="480px" src="https://github.com/flutter-devs/flutter_video_recorder/blob/master/screens/iphone2.jpg"> <img height="480px" src="https://github.com/flutter-devs/flutter_video_recorder/blob/master/screens/iphone3.jpg"> 



## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
